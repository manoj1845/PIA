import * as packageJson from '../../package.json';
export const environment = {
  name: 'production',
  production: true,
  version: packageJson.version
};
