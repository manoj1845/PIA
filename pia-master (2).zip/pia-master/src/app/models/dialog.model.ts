export class Dialog  {
  text: string;
  type: string;
  yes: string;
  no: string;
  data?: any;
  icon?: string;
}
