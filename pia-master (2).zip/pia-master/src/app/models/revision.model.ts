export class Revision{
  public id: number;
  public export: any;
  public pia_id: number;
  public created_at: Date;
}
