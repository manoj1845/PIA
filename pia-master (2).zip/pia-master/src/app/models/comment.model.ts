export class Comment {
  public id: number;
  public description: string;
  public for_measure: boolean;
  public reference_to;
  public pia_id: number;
  public created_at: Date;
  public updated_at: Date;
}
